const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("admin123", 10);

  const user = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      name: "Administrador",
      email: "admin@example.com",
      passwordHash
    }
  });

  await prisma.product.upsert({
    where: {
      userId_platform_externalProductId: {
        userId: user.id,
        platform: "MERCADO_LIVRE",
        externalProductId: "demo-001"
      }
    },
    update: {},
    create: {
      userId: user.id,
      platform: "MERCADO_LIVRE",
      externalProductId: "demo-001",
      title: "Produto demonstrativo",
      originalUrl: "https://www.mercadolivre.com.br/",
      price: 49.90,
      commissionRate: 0.10
    }
  });

  console.log("Seed concluído.");
}

main().finally(() => prisma.$disconnect());
