const { Queue } = require("bullmq");

const connection = {
  host: process.env.REDIS_HOST || "localhost",
  port: Number(process.env.REDIS_PORT || 6379)
};

const automationQueue = new Queue("automation", { connection });

module.exports = { automationQueue, connection };
