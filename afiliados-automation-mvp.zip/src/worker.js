require("dotenv").config();

const { Worker } = require("bullmq");
const { connection } = require("./queue");
const prisma = require("./db");
const { convertToAffiliateLink } = require("./services/affiliate");

const worker = new Worker("automation", async job => {
  if (job.name === "convert-link") {
    return {
      affiliateUrl: await convertToAffiliateLink(
        job.data.originalUrl,
        job.data.userId
      )
    };
  }

  if (job.name === "publish") {
    // Adaptador de publicação. A integração oficial de cada rede
    // deve ser implementada no connector correspondente.
    return { status: "READY_FOR_CONNECTOR", destination: job.data.destination };
  }

  if (job.name === "generate-video") {
    return { status: "READY_FOR_MEDIA_PIPELINE", productId: job.data.productId };
  }

  throw new Error("Tipo de job desconhecido");
}, { connection });

worker.on("completed", job => {
  console.log(`Job ${job.id} concluído`);
});

worker.on("failed", (job, err) => {
  console.error(`Job ${job?.id} falhou:`, err.message);
});
