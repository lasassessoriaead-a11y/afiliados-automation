require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const bcrypt = require("bcryptjs");
const prisma = require("./db");
const { sign, auth } = require("./auth");
const { automationQueue } = require("./queue");
const { convertToAffiliateLink } = require("./services/affiliate");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });

  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: "E-mail ou senha inválidos." });
  }

  res.json({
    token: sign(user),
    user: { id: user.id, name: user.name, email: user.email }
  });
});

app.get("/api/dashboard", auth, async (req, res) => {
  const [products, jobs, campaigns, clicks] = await Promise.all([
    prisma.product.count({ where: { userId: req.user.id } }),
    prisma.job.count({ where: { userId: req.user.id } }),
    prisma.campaign.count({ where: { userId: req.user.id } }),
    prisma.metric.aggregate({
      where: { userId: req.user.id },
      _sum: { clicks: true, conversions: true, spend: true, revenue: true }
    })
  ]);

  res.json({
    products,
    jobs,
    campaigns,
    clicks: clicks._sum.clicks || 0,
    conversions: clicks._sum.conversions || 0,
    spend: Number(clicks._sum.spend || 0),
    revenue: Number(clicks._sum.revenue || 0)
  });
});

app.get("/api/products", auth, async (req, res) => {
  const products = await prisma.product.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: "desc" }
  });
  res.json(products);
});

app.post("/api/products", auth, async (req, res) => {
  const { platform, externalProductId, title, originalUrl, price, commissionRate, imageUrl } = req.body;

  const product = await prisma.product.create({
    data: {
      userId: req.user.id,
      platform,
      externalProductId,
      title,
      originalUrl,
      price: price == null ? null : Number(price),
      commissionRate: commissionRate == null ? null : Number(commissionRate),
      imageUrl
    }
  });

  res.status(201).json(product);
});

app.get("/api/credentials", auth, async (req, res) => {
  const list = await prisma.credential.findMany({
    where: { userId: req.user.id },
    select: {
      id: true, platform: true, affiliateTag: true,
      externalAccountId: true, expiresAt: true, createdAt: true
    }
  });
  res.json(list);
});

app.post("/api/credentials", auth, async (req, res) => {
  const { platform, accessToken, refreshToken, affiliateTag, externalAccountId, expiresAt } = req.body;

  const credential = await prisma.credential.upsert({
    where: { userId_platform: { userId: req.user.id, platform } },
    update: { accessToken, refreshToken, affiliateTag, externalAccountId, expiresAt: expiresAt ? new Date(expiresAt) : null },
    create: { userId: req.user.id, platform, accessToken, refreshToken, affiliateTag, externalAccountId, expiresAt: expiresAt ? new Date(expiresAt) : null }
  });

  res.json({
    id: credential.id,
    platform: credential.platform,
    affiliateTag: credential.affiliateTag
  });
});

app.post("/api/affiliate/convert", auth, async (req, res) => {
  try {
    const { originalUrl } = req.body;
    const affiliateUrl = await convertToAffiliateLink(originalUrl, req.user.id);
    res.json({ originalUrl, affiliateUrl });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.post("/api/jobs", auth, async (req, res) => {
  const { type, productId, scheduledAt, payload } = req.body;

  const job = await prisma.job.create({
    data: {
      userId: req.user.id,
      productId: productId || null,
      type,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      payload
    }
  });

  const delay = scheduledAt
    ? Math.max(0, new Date(scheduledAt).getTime() - Date.now())
    : 0;

  await automationQueue.add(
    type === "CONVERT_LINK" ? "convert-link" :
    type === "GENERATE_VIDEO" ? "generate-video" : "publish",
    { ...payload, userId: req.user.id, productId },
    { delay, attempts: 3, backoff: { type: "exponential", delay: 5000 } }
  );

  res.status(201).json(job);
});

app.get("/api/jobs", auth, async (req, res) => {
  res.json(await prisma.job.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: "desc" },
    take: 100
  }));
});

app.get("/api/metrics", auth, async (req, res) => {
  res.json(await prisma.metric.findMany({
    where: { userId: req.user.id },
    orderBy: { date: "desc" },
    take: 100
  }));
});

app.use((req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Afiliados Automation: http://localhost:${port}`));
