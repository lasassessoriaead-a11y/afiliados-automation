const prisma = require("../db");
const { convert } = require("../connectors");

async function convertToAffiliateLink(originalUrl, userId) {
  const platform = require("../connectors").detectPlatform(originalUrl);
  if (!platform) throw new Error("Marketplace não suportado.");

  const credential = await prisma.credential.findUnique({
    where: {
      userId_platform: { userId, platform }
    }
  });

  const result = await convert({
    url: originalUrl,
    credential
  });

  return result.affiliateUrl;
}

module.exports = { convertToAffiliateLink };
