const crypto = require("crypto");

function detectPlatform(url) {
  const u = url.toLowerCase();

  if (u.includes("shopee.")) return "SHOPEE";
  if (u.includes("mercadolivre.") || u.includes("mercadolibre.")) return "MERCADO_LIVRE";
  if (u.includes("tiktok.com")) return "TIKTOK_SHOP";

  return null;
}

function appendDemoTag(url, tag) {
  if (!tag) return url;
  const separator = url.includes("?") ? "&" : "?";
  return `${url}${separator}ref=${encodeURIComponent(tag)}`;
}

async function convert({ url, credential }) {
  const platform = detectPlatform(url);

  if (!platform) {
    throw new Error("URL de marketplace não reconhecida.");
  }

  /*
   * Em produção, substitua este trecho pelo endpoint oficial
   * da plataforma correspondente.
   *
   * O MVP não inventa endpoints comerciais nem tenta contornar
   * autenticação. Se houver affiliateTag configurada, usamos
   * uma transformação demonstrativa para testar o fluxo.
   */
  const affiliateUrl = appendDemoTag(url, credential?.affiliateTag);

  return {
    platform,
    originalUrl: url,
    affiliateUrl,
    requestId: crypto.randomUUID(),
    mode: credential?.affiliateTag ? "demo-tag" : "original"
  };
}

module.exports = { detectPlatform, convert };
