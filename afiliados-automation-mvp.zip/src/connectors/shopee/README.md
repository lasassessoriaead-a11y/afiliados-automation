# Connector shopee

Implementar aqui somente a integração oficial da plataforma, usando as credenciais e permissões autorizadas da conta.
