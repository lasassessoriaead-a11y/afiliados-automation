# Afiliados Automation — MVP

Plataforma base para automação de afiliados com:
- Dashboard
- Usuários e login
- Credenciais por marketplace
- Cadastro/mineração de produtos
- Conversão de URLs em links de afiliado por conector
- Fila de tarefas
- Agendamento de publicações
- Métricas
- Estrutura pronta para conectores Shopee, Mercado Livre e TikTok Shop
- PostgreSQL + Prisma
- Redis + BullMQ
- Docker Compose

## Importante
O sistema é funcional como plataforma e motor de automação, mas as integrações comerciais reais dependem das credenciais, permissões, aprovação e endpoints oficiais disponíveis para cada conta/plataforma.

Não há implementação de scraping/bypass de proteção ou republicação de conteúdo de terceiros sem autorização.

## Requisitos
- Docker Desktop
- Node.js 20+

## Subir o banco e Redis
```bash
docker compose up -d
```

## Instalar
```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run seed
```

## Rodar
```bash
npm run dev
```

Abra:
http://localhost:3000

Usuário inicial:
- e-mail: admin@example.com
- senha: admin123

Altere a senha em produção.

## API principal
- POST /api/auth/login
- GET /api/dashboard
- GET /api/products
- POST /api/products
- POST /api/affiliate/convert
- GET /api/credentials
- POST /api/credentials
- GET /api/jobs
- POST /api/jobs
- GET /api/metrics
