# Afiliados Automation — Web UI

Esta pasta contém uma versão web completa da interface do projeto, pronta para ser aberta no navegador e usada como front-end.

## Abrir imediatamente
Abra `public/index.html` no navegador.

Para hospedar:
- GitHub Pages
- Netlify
- Vercel
- Cloudflare Pages

## Importante
A interface já está montada com as telas e fluxos do projeto. Os módulos que dependem de APIs externas (Shopee, Mercado Livre, TikTok Shop, Meta Ads, TikTok Ads, Instagram, TikTok e YouTube) precisam das credenciais, OAuth, permissões e endpoints oficiais de cada serviço para executar operações reais.

A versão anterior do projeto contém o backend Node/PostgreSQL/Redis. Esta versão web pode ser conectada a ele trocando os dados demonstrativos pelos endpoints `/api/*`.

Não implementa scraping/bypass ou republicação não autorizada de conteúdo de terceiros.
